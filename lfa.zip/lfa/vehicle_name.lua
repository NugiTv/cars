Citizen.CreateThread(function()
    AddTextEntry("0x9AE8B033", "LFA"),
end)
